# Semana 1: Llegar y sobrevivir 🚀

# Bienvenida al curso

![Logo del festival](img/kartel.png)

¡Willkommen! 🎉  
Has llegado a Berlín con muchas ganas de vivir la música, la cultura… ¡y probablemente con cero alemán! Pero no te preocupes. Este curso te da lo esencial para *sobrevivir (y disfrutar)* desde el momento en que aterrizas.

---

## ✈️ En el aeropuerto: Primeros pasos

### 🧳 Escenario 1: Llegada

Acabas de aterrizar en el aeropuerto BER (Flughafen Berlin Brandenburg). Estás cansado, tu móvil no tiene conexión y hay carteles por todas partes… en alemán.  

Primera misión: **Recoger tu equipaje y salir del aeropuerto.**

---

### 📘 Vocabulario esencial

|| Alemán              | Español               | Pronunciación |
|---------------------|------------------------|----------------|
| der Flughafen       | el aeropuerto          | [flúkhafen]    |
| der Ausgang         | la salida              | [áusgang]      |
| der Koffer          | la maleta              | [kóffer]       |
| das Gepäck          | el equipaje            | [guepék]       |
| der Zug             | el tren                | [tsuk]         |
| die U-Bahn          | el metro               | [ú-bán]        |
| die S-Bahn          | tren suburbano         | [és-bán]       |
| die Fahrkarte       | el billete             | [fárkarte]     |
| das Gleis           | el andén               | [glais]        |
| die Information     | la información         | [informatsión] |
| Entschuldigung      | Perdón / Disculpe      | [entshúldigung]|
| Ich habe mich verlaufen | Me he perdido     | [ij hábe mij ferláufen] |
---

## 🗣️ Frases útiles en el aeropuerto

- **Ich habe meinen Koffer verloren.** – He perdido mi maleta.  
- **Wo ist die Gepäckausgabe?** – ¿Dónde está la recogida de equipaje?  
- **Ich bin Tourist.** – Soy turista.  
- **Können Sie mir helfen?** – ¿Puede ayudarme?  
- **Gibt es WLAN hier?** – ¿Hay wifi aquí?

---

## 🚇 Escenario 2: Moverte por la ciudad

### Tipos de transporte

| Transporte     | Alemán        | Notas                            |
|----------------|---------------|----------------------------------|
| Metro          | die U-Bahn    | Rápido, en todo Berlín           |
| Tren suburbano | die S-Bahn    | Ideal para distancias largas     |
| Autobús        | der Bus       | Pasa frecuentemente, incluso noche |
| Tranvía        | die Straßenbahn | Sobre todo en el este de Berlín |
| Taxi           | das Taxi      | Caro, pero seguro y legal        |

---

### 📘 Más frases esenciales

- **Ich möchte nach Kreuzberg fahren.** – Quiero ir a Kreuzberg.  
- **Wo ist die nächste U-Bahn-Station?** – ¿Dónde está la estación de metro más cercana?  
- **Ich habe kein Ticket.** – No tengo billete.  
- **Ich muss umsteigen.** – Tengo que hacer transbordo.  
- **Wie lange dauert die Fahrt?** – ¿Cuánto dura el trayecto?

---

## 🧭 Entender las señales

En Alemania, los carteles suelen ser muy claros, pero en alemán. Aquí tienes algunos imprescindibles:

- **Ausgang** – salida  
- **Eingang** – entrada  
- **Toiletten / WC** – baños  
- **Gepäckausgabe** – recogida de equipaje  
- **Fahrkartenautomat** – máquina expendedora de billetes  
- **Information** – punto de información  
- **Notausgang** – salida de emergencia  
- **Richtung Zentrum** – dirección centro
  
---

## 📲 Apps imprescindibles para sobrevivir

- **BVG Fahrinfo**: App oficial del transporte público. Muestra horarios, rutas, billetes.
- **DB Navigator**: Ideal si usas trenes regionales (RE).
- **Google Maps**: Funciona bien para ver cómo ir de A a B en transporte público.
- **DeepL / Google Translate**: Traducción rápida, incluso con cámara.
- **WLAN Berlin Free**: Algunas estaciones tienen wifi gratis, pero es limitado.

---

## 💥 ¡En caso de emergencia!

Aquí van frases y palabras clave que podrías necesitar y *esperamos que no*:

- **Hilfe!** – ¡Ayuda!  
- **Notrufnummer** – Número de emergencia  
- **Ich bin verletzt.** – Estoy herido/a  
- **Ich brauche einen Arzt.** – Necesito un médico  
- **Polizei / Feuerwehr / Krankenwagen** – Policía / Bomberos / Ambulancia  
- 📞 **112** – Número de emergencias en Alemania

📝 *Tip:* Los alemanes son directos pero amables. Si necesitas ayuda, ¡pide sin miedo!

---

## ❗️Errores comunes (y cómo evitarlos)

| Error                  | Solución o alternativa                        |
|------------------------|-----------------------------------------------|
| No validar el billete  | Busca las máquinas amarillas o rojas en el andén y valida antes de subir. |
| Hablar en inglés sin preguntar | Usa “Sprechen Sie Englisch?” antes de lanzarte. |
| Asumir que todo está abierto | Berlín no es 24h. Verifica horarios. |
| Subir a cualquier tren | Fíjate en el destino y el número del andén (Gleis). |

---

## 🎒 Cultura urbana alemana

- La puntualidad es sagrada: un tren que sale a las 12:00 *sale a las 12:00*.
- En los trenes y metros **no hay torniquetes**, pero sí revisores sorpresa.
- Lleva siempre **efectivo**: no todos los lugares aceptan tarjeta.
- Berlín es segura, pero **vigila tus cosas** en estaciones concurridas.
- **Silencio**: La gente no habla mucho en el transporte público. Es normal.
- **Modales**: Di "Entschuldigung" al pasar entre personas. Un “bitte” o “danke” nunca está de más.
- **Horarios nocturnos**: Hay transporte nocturno, pero no tan frecuente. Verifica antes.


---

## 🎧 Frases extra para practicar

> Entschuldigung, ich bin Tourist.  
> Ich habe kein Netz.  
> Wie heißt diese Station?  
> Ich verstehe nicht.

🎧 *Repite con diferentes emociones: confundido/a, seguro/a, nervioso/a, curioso/a.*

---

## 📥 Recursos de esta semana

- 🖨️ **PDF de ejercicios:** [semana1-ejercicios.pdf](../pdfs/semana1-ejercicios.pdf)  
- 🎧 **Audio frases útiles:** [semana1-audio.mp3](../audios/semana1-audio.mp3)  
- 📱 **Apps recomendadas:** ver en [semana1-apps.pdf](../pdfs/semana1-apps.pdf)

---

## ✅ Lo que ya sabes hacer

- [x] Orientarte en el aeropuerto y estaciones
- [x] Preguntar cómo llegar a un lugar
- [x] Preguntar por transporte y direcciones
- [x] Evitar errores comunes de novato/a
- [x] Usar frases de emergencia básicas
- [x] Leer señales importantes
- [x] Usar transporte público sin quedar como un turista perdido 🧭

---

## 🔜 Spoiler de la próxima semana…

**Semana 2: Alimentarte y no morir en el intento 🍔🍟🍺**  
Aprenderás a pedir comida en alemán, entender menús, sobrevivir a la palabra *Sauerkraut* y evitar pedir hígado por error.
¡Ya casi hueles el currywurst!

---
